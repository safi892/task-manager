class Task {
  String title;
  String description;
  bool isCompleted;
  DateTime? dueDate;       
  String? priority;    
  bool isFavourite;
    

  Task({
    required this.title,
    required this.description,
    this.isCompleted = false,
    this.dueDate,          
    this.priority,      
    this.isFavourite = false,
  });
    Task copyWith({
    String? title,
    String? description,
    DateTime? dueDate,
    String? priority,
    bool? isCompleted,
  }) {
    return Task(
      title: title ?? this.title,
      description: description ?? this.description,
      dueDate: dueDate ?? this.dueDate,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
}